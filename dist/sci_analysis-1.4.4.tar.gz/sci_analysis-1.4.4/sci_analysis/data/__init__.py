"""sci_analysis package: data
Modules:
    data - the sci_analysis Data class
    operations - sci_analysis Data functions
    vector - the sci_analysis Vector class
"""
# from vector import Vector
from .data import *
