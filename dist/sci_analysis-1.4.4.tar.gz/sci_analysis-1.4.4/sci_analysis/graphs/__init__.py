"""sci_analysis package: graphs
Modules:
    graphs - graphing classes
"""

# from graph import *
